"""
Execution Engine — Bot Q3 Beta
THE single execution path. All trades — manual and automatic — go through here.
No parallel logic. No duplicated paths.
"""
import asyncio
import logging
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Optional, Dict, Tuple

from core.risk_manager import RiskManager
from core.martingale_manager import MartingaleManager
from db import database

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class ExecutionEngine:
    """
    Unified execution pipeline:

    execute(signal) ->
        1. Slippage measurement
        2. RiskManager validation (stop loss, consecutive losses, payout, Kelly)
        3. MartingaleManager sizing
        4. IQ client execution
        5. Order confirmation (order_id existence = success)
        6. DB trade insert
        7. Result settlement (buy_blitz returns result synchronously)
        8. DB result update
        9. Martingale state update
        10. Daily stats update
        11. Telegram notification callback

    CONCORRENCIA: asyncio.Semaphore(max_ops) garante que nunca mais do que
    max_operacoes_simultaneas ordens rodem ao mesmo tempo, eliminando race
    conditions no Martingale e no RiskManager.
    """

    def __init__(
        self,
        iq_client,
        risk_manager: RiskManager,
        martingale_manager: MartingaleManager,
        global_config: dict,
        notify_callback=None,
    ):
        self.iq = iq_client
        self.risk = risk_manager
        self.martingale = martingale_manager
        self._cfg = global_config
        self._notify = notify_callback  # async fn(message: str)

        # Semaphore: limita execucoes simultaneas ao valor configurado em
        # max_operacoes_simultaneas (padrao 3). Inicializado com o valor
        # atual do CONFIG; se o usuario mudar a config em runtime o semaphore
        # mantem o valor original -- o que e seguro e conservador.
        max_ops = int(global_config.get("max_operacoes_simultaneas", 3))
        self._semaphore = asyncio.Semaphore(max_ops)
        # Lock global: garante apenas um trade por vez passando pela pipeline completa
        self._trade_lock = asyncio.Lock()

    async def execute(self, signal: Dict, signal_received_at: datetime = None) -> Dict:
        """
        Execute a trade signal end-to-end.

        signal keys: par, direcao, tempo_expiracao, [imediato, horario]
        signal_source: "manual" | "auto_generator" | "auto_trader"

        Returns result dict with all trade metadata.
        """
        # Lock global garante execucao serial — sem race condition em Martingale/RiskManager
        async with self._trade_lock:
            # Semaphore como segunda camada de controle de concorrencia
            async with self._semaphore:
                return await self._execute_inner(signal, signal_received_at)

    async def _execute_inner(self, signal: Dict, signal_received_at: datetime = None) -> Dict:
        if signal_received_at is None:
            signal_received_at = datetime.now(TZ)

        asset = signal.get("par", "")
        direction = signal.get("direcao", "").upper()
        expiracao = int(signal.get("tempo_expiracao", 60))
        signal_source = signal.get("signal_source", "manual")
        signal_id = signal.get("signal_id")

        # -- 1. Slippage --
        now = datetime.now(TZ)
        if signal_received_at.tzinfo is None:
            signal_received_at = signal_received_at.replace(tzinfo=TZ)
        slippage_ms = max(0, int((now - signal_received_at).total_seconds() * 1000))
        logger.info(f"Slippage: {slippage_ms}ms | {asset} {direction}")

        # -- 2. Validate asset live & get payout --
        # Verificar e garantir conexão antes de cada trade
        if not self.iq.esta_conectado():
            logger.warning("Conexão perdida, tentando reconectar...")
            try:
                await self.iq.conectar(max_tentativas=1)
            except:
                pass
            
            if not self.iq.esta_conectado():
                await self._notify_err("IQ Option desconectado")
                return self._fail("desconectado")
        
        # Verificar tipo de conta e avisar se REAL
        tipo_conta = await self.iq.obter_tipo_conta_async()
        if tipo_conta == "REAL":
            if self._notify:
                await self._notify("⚠️ <b>OPERANDO EM CONTA REAL</b>")
        
        validation = await self.iq._integration.validate_asset_live(asset)
        if not validation.get("valid"):
            msg = validation.get("error", "Ativo indisponivel")
            await self._notify_err(f"{asset}: {msg}")
            return self._fail(msg)

        payout_pct = float(validation.get("payout", 0))

        # -- 3. Risk validation --
        can_exec, reason, amount = await self.risk.validar_operacao(
            signal, payout_pct, slippage_ms
        )
        if not can_exec:
            await self._notify_err(f"Bloqueado: {reason}")
            return self._fail(reason)

        # -- 4. Martingale sizing --
        if self.martingale.enabled:
            mg_amount, mg_level = self.martingale.get_next_value()
            if mg_amount == 0.0:
                await self._notify_err(
                    f"Martingale no nivel maximo ({mg_level})\n"
                    "Use /resetmartingale para reiniciar."
                )
                return self._fail("martingale_max_level")
            amount = mg_amount
            martingale_level = mg_level
        else:
            martingale_level = 0

        # -- 5. Balance check --
        saldo = await self.iq.obter_saldo()
        if saldo < amount:
            msg = f"Saldo insuficiente (${saldo:.2f} < ${amount:.2f})"
            await self._notify_err(msg)
            return self._fail(msg)

        # -- 6. Notify pre-execution --
        if self._notify:
            await self._notify(
                f"⚡ <b>Executando</b>\n"
                f"📊 {asset} {direction} · {expiracao}s\n"
                f"💰 ${amount:.2f} · Payout {payout_pct:.0f}%"
                + (f" · Martingale L{martingale_level}" if self.martingale.enabled else "")
            )

        # -- 7. Insert pre-result trade record --
        trade_id = await database.insert_trade(
            asset=asset,
            direction=direction,
            amount=amount,
            payout=payout_pct,
            martingale_level=martingale_level,
            slippage_ms=slippage_ms,
            signal_source=signal_source,
            signal_id=signal_id,
        )

        # -- 8. Execute trade --
        self.risk.registrar_inicio()
        execution_start = datetime.now(TZ)

        try:
            ok, order_id, error_msg = await self.iq.executar_ordem(
                asset, direction, amount, expiracao
            )
        except Exception as e:
            self.risk.registrar_fim()
            logger.error(f"Execution exception: {e}", exc_info=True)
            return self._fail(str(e))

        # -- 9. Confirm order --
        if not ok or not order_id:
            self.risk.registrar_fim()
            msg = error_msg or "Ordem nao confirmada pela API"
            await self._notify_err(f"{asset} {direction} -- {msg}")
            return self._fail(msg)

        exec_ms = int((datetime.now(TZ) - execution_start).total_seconds() * 1000)
        logger.info(f"Ordem executada: ID={order_id} em {exec_ms}ms")

        # -- 10. Settlement --
        result_str, pnl = await self._settle(order_id, asset, direction, amount, expiracao)
        self.risk.registrar_fim()

        # -- 11. DB updates --
        await database.update_trade_result(trade_id, result_str, pnl, order_id)
        await database.upsert_daily(result_str, pnl)

        # -- 12. Martingale update --
        if self.martingale.enabled:
            await self.martingale.register_result(result_str)

        # -- 13. Notify result --
        today = await database.get_today_stats()
        emoji_result = {"WIN": "✅", "LOSS": "❌", "EMPATE": "⚖️"}.get(result_str, "❓")
        saldo_novo = await self.iq.obter_saldo()

        mg_status = ""
        if self.martingale.enabled:
            st = self.martingale.get_status()
            if result_str == "LOSS" and st["level"] < st["max_levels"]:
                mg_status = f"\n🎲 Martingale L{st['level']} · Próximo: ${st['next_value']:.2f}"
            elif result_str == "WIN":
                mg_status = "\n🎲 Martingale resetado"

        if self._notify:
            await self._notify(
                f"{emoji_result} <b>{asset} {direction} · {result_str}</b>\n"
                f"💰 P&L: ${pnl:+.2f} · Saldo: ${saldo_novo:.2f}\n"
                f"📈 Dia: {today['wins']}W {today['losses']}L {today['draws']}E · "
                f"{today['winrate']:.0f}% · ${today['pnl']:+.2f}"
                + mg_status
            )

        return {
            "success": True,
            "order_id": order_id,
            "result": result_str,
            "pnl": pnl,
            "amount": amount,
            "payout": payout_pct,
            "slippage_ms": slippage_ms,
            "martingale_level": martingale_level,
        }

    # -------------------------------------------------------
    # SETTLEMENT
    # -------------------------------------------------------

    async def _settle(
        self,
        order_id: str,
        asset: str,
        direction: str,
        amount: float,
        expiracao: int,
    ) -> Tuple[str, float]:
        """
        Tenta obter o resultado direto do cache da integration layer
        (resultado ja resolvido pelo buy_blitz). Se nao estiver disponivel
        imediatamente, aguarda com polling leve ate timeout.
        """
        def _extrair_cache() -> Optional[Dict]:
            if hasattr(self.iq, "_integration") and hasattr(self.iq._integration, "_last_trade_result"):
                return self.iq._integration._last_trade_result.get(str(order_id))
            return None

        def _parse(result_data: Dict) -> Tuple[str, float]:
            outcome = result_data.get("result", "").lower()
            pnl_raw = float(result_data.get("pnl", 0.0))
            if outcome == "win":
                return "WIN", abs(pnl_raw)
            elif outcome in ("loose", "loss"):
                return "LOSS", -abs(amount)
            elif outcome == "equal":
                return "EMPATE", 0.0
            return "DESCONHECIDO", 0.0

        # Normalizar order_id para string (API pode retornar int ou str)
        order_id = str(order_id)

        # Tentativa imediata (buy_blitz sincrono ja resolveu)
        result_data = _extrair_cache()
        if result_data:
            logger.info(f"Settlement imediato (cache) para {order_id}")
            return _parse(result_data)

        # Fallback: aguarda ate expiracao + 35s
        timeout = expiracao + 35
        for waited in range(1, timeout + 1):
            await asyncio.sleep(1)
            result_data = _extrair_cache()
            if result_data:
                logger.info(f"Settlement recebido apos {waited}s para {order_id}")
                return _parse(result_data)

        logger.warning(f"Settlement timeout ({timeout}s) para {order_id}. Registrando como LOSS.")
        return "LOSS", -abs(amount)

    # -------------------------------------------------------
    # HELPERS
    # -------------------------------------------------------

    @staticmethod
    def _fail(reason: str) -> Dict:
        return {"success": False, "reason": reason}

    async def _notify_err(self, msg: str):
        if self._notify:
            await self._notify(msg)
        logger.warning(msg)
