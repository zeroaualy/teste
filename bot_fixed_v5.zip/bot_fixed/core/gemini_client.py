"""
Gemini Client — Bot Q3 Beta
REST API segura com rate limiter global, semáforo, retry controlado e logging.

ARQUITETURA DE SEGURANÇA:
- Semáforo global (asyncio.Semaphore(1)): NUNCA duas chamadas paralelas
- Rate limiter: mínimo 15s entre requisições (~4 req/min, muito abaixo do limite)
- Retry controlado: máx 2 tentativas, delays 20s e 40s
- safe_generate(): único gateway — todos os módulos obrigatoriamente passam por aqui
- Logging completo de cada etapa para diagnóstico
"""
import asyncio
import logging
import time
import requests
from typing import Optional, List, Dict

logger = logging.getLogger(__name__)

MODEL = "gemini-2.0-flash"
BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

# ── Configurações de rate limit e retry ──────────────────────────────────────
MIN_INTERVAL_SECONDS: float = 15.0   # 1 req a cada 15s = ~4 req/min (conservador)
MAX_RETRIES: int = 2                  # máximo 2 tentativas após a primeira
RETRY_DELAYS: list = [20.0, 40.0]    # delay crescente entre tentativas
REQUEST_TIMEOUT: int = 45            # timeout HTTP por requisição

# ── Singleton de controle global ─────────────────────────────────────────────
# Compartilhado por todos os módulos — garante serialização global
_global_semaphore: Optional[asyncio.Semaphore] = None
_last_request_time: float = 0.0
_semaphore_lock = asyncio.Lock()


def _get_semaphore() -> asyncio.Semaphore:
    """Retorna o semáforo global singleton, criando se necessário."""
    global _global_semaphore
    if _global_semaphore is None:
        _global_semaphore = asyncio.Semaphore(1)
        logger.info("✅ Gemini semáforo global criado (Semaphore(1))")
    return _global_semaphore


class GeminiClient:

    def __init__(self, api_key: str, project_id: str = None):
        if not api_key:
            raise ValueError("GEMINI_API_KEY é obrigatória")
        self.api_key = api_key.strip()
        self.model_name = MODEL
        logger.info(f"✅ GeminiClient pronto — {self.model_name}")

    def _http_request(self, prompt: str, temperature: float,
                      max_output_tokens: int) -> str:
        """
        Executa a requisição HTTP ao Gemini.
        NÃO chame diretamente — use safe_generate() ou analisar_contexto().
        """
        url = f"{BASE_URL}/{self.model_name}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "X-goog-api-key": self.api_key,
        }
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_output_tokens,
            }
        }
        resp = requests.post(url, json=payload, headers=headers,
                             timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
        return data["candidates"][0]["content"]["parts"][0]["text"]

    def generate(self, prompt: str, temperature: float = 0.7,
                 max_output_tokens: int = 512) -> str:
        """
        Chamada síncrona simples — usada internamente pelo ChatCompletions.
        Não possui controle de concorrência — para uso assíncrono use safe_generate().
        """
        global _last_request_time

        # Rate limit síncrono básico
        elapsed = time.time() - _last_request_time
        if elapsed < MIN_INTERVAL_SECONDS:
            wait = MIN_INTERVAL_SECONDS - elapsed
            logger.info(f"⏳ GEMINI WAITING RATE LIMIT — {wait:.1f}s")
            time.sleep(wait)

        _last_request_time = time.time()
        return self._http_request(prompt, temperature, max_output_tokens)

    async def safe_generate(self, prompt: str, temperature: float = 0.7,
                            max_output_tokens: int = 512) -> Optional[str]:
        """
        ÚNICO GATEWAY SEGURO para chamadas assíncronas ao Gemini.

        Garante:
        - Nunca duas chamadas paralelas (Semaphore(1))
        - Intervalo mínimo de 15s entre requisições
        - Máximo 2 retentativas com delays 20s e 40s
        - Logging completo de cada etapa

        Returns:
            Texto da resposta ou None em caso de falha permanente.
        """
        global _last_request_time

        semaphore = _get_semaphore()

        logger.info("🔒 GEMINI LOCK ACQUIRED — aguardando semáforo")
        async with semaphore:
            logger.info("✅ GEMINI LOCK ACQUIRED — iniciando pipeline")

            for tentativa in range(MAX_RETRIES + 1):
                try:
                    # Rate limit assíncrono
                    elapsed = time.monotonic() - _last_request_time
                    if elapsed < MIN_INTERVAL_SECONDS and _last_request_time > 0:
                        wait = MIN_INTERVAL_SECONDS - elapsed
                        logger.info(
                            f"⏳ GEMINI WAITING RATE LIMIT — {wait:.1f}s "
                            f"(tentativa {tentativa + 1}/{MAX_RETRIES + 1})"
                        )
                        await asyncio.sleep(wait)

                    logger.info(
                        f"🚀 GEMINI REQUEST START — "
                        f"tentativa {tentativa + 1}/{MAX_RETRIES + 1}"
                    )

                    loop = asyncio.get_event_loop()
                    _last_request_time = time.monotonic()

                    resultado = await asyncio.wait_for(
                        loop.run_in_executor(
                            None,
                            lambda: self._http_request(
                                prompt, temperature, max_output_tokens
                            )
                        ),
                        timeout=float(REQUEST_TIMEOUT)
                    )

                    logger.info("✅ GEMINI REQUEST END — sucesso")
                    logger.info("🔓 GEMINI LOCK RELEASED")
                    return resultado

                except asyncio.TimeoutError:
                    logger.warning(
                        f"⏱️ GEMINI BLOCKED — timeout {REQUEST_TIMEOUT}s "
                        f"(tentativa {tentativa + 1}/{MAX_RETRIES + 1})"
                    )

                except requests.exceptions.HTTPError as e:
                    status = e.response.status_code if e.response else 0
                    if status == 429:
                        logger.warning(
                            f"🚫 GEMINI BLOCKED — 429 rate limit "
                            f"(tentativa {tentativa + 1}/{MAX_RETRIES + 1})"
                        )
                    else:
                        logger.error(
                            f"❌ GEMINI REQUEST END — HTTP {status}: {e} "
                            f"(tentativa {tentativa + 1}/{MAX_RETRIES + 1})"
                        )
                        if status in (400, 401, 403):
                            # Erros permanentes — não retenta
                            logger.error("❌ GEMINI LOCK RELEASED — erro permanente, abortando")
                            return None

                except Exception as e:
                    logger.error(
                        f"❌ GEMINI REQUEST END — erro inesperado: {e} "
                        f"(tentativa {tentativa + 1}/{MAX_RETRIES + 1})"
                    )

                # Aguarda antes de retentar (exceto na última tentativa)
                if tentativa < MAX_RETRIES:
                    delay = RETRY_DELAYS[tentativa]
                    logger.info(f"🔄 GEMINI RETRY — aguardando {delay}s antes da tentativa {tentativa + 2}")
                    await asyncio.sleep(delay)

            logger.error("❌ GEMINI LOCK RELEASED — todas as tentativas falharam")
            return None

    async def analisar_contexto(self, prompt: str, temperature: float = 0.7) -> str:
        """
        Interface assíncrona usada pelos geradores de sinal.
        Passa obrigatoriamente pelo safe_generate() — único gateway.
        """
        resultado = await self.safe_generate(prompt, temperature)
        if resultado is None:
            raise RuntimeError("Gemini não retornou resposta após todas as tentativas")
        return resultado

    # ── Compatibilidade com interface OpenAI (usado pelo IAGuard) ────────────

    class ChatCompletions:
        def __init__(self, client):
            self.client = client

        def create(self, model: str, messages: List[Dict],
                   temperature: float = 0.7, max_tokens: Optional[int] = None):
            prompt = next(
                (m.get("content", "") for m in messages if m.get("role") == "user"), ""
            )
            text = self.client.generate(
                prompt, temperature=temperature,
                max_output_tokens=max_tokens or 512
            )

            class Choice:
                def __init__(self, t):
                    self.message = type("M", (), {"content": t})()

            class Response:
                def __init__(self, t):
                    self.choices = [Choice(t)]

            return Response(text)

    @property
    def chat(self):
        client = self
        class Chat:
            def __init__(self):
                self.completions = GeminiClient.ChatCompletions(client)
        return Chat()
