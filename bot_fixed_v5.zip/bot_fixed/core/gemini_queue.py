"""
Gemini Queue — Bot Q3 Beta
Fila assíncrona global que serializa TODAS as chamadas ao Gemini.

PROBLEMA QUE RESOLVE:
    FutureSignalGenerator e AutoSignalGenerator chamam analisar_contexto()
    ao mesmo tempo → ambos passam pelo rate limiter síncrono simultaneamente
    → dois requests chegam juntos na API → 429.

SOLUÇÃO:
    Uma única fila asyncio.Queue processa as chamadas uma por vez,
    com intervalo mínimo configurável entre elas. Qualquer módulo que
    chame analisar_contexto() entra na fila e aguarda sua vez.

ISOLAMENTO:
    - Não altera nenhuma interface existente
    - Não modifica generate() síncrono
    - Apenas analisar_contexto() passa pela fila
    - Falha silenciosa: se a fila falhar, chama diretamente

USO (interno — não chamar diretamente):
    A fila é usada automaticamente pelo GeminiClient.analisar_contexto()
"""

import asyncio
import logging
import time
from typing import Callable, Any, Optional

logger = logging.getLogger(__name__)

# Intervalo mínimo entre chamadas em segundos
# 6s = ~10 req/min (conservador abaixo do limite de 12/min configurado)
MIN_INTERVAL_SECONDS: float = 6.0

# Timeout máximo que uma tarefa pode aguardar na fila antes de desistir
QUEUE_TIMEOUT_SECONDS: float = 120.0


class GeminiRequestQueue:
    """
    Fila assíncrona singleton que processa requisições ao Gemini
    uma por vez com intervalo mínimo entre elas.
    """

    def __init__(self, min_interval: float = MIN_INTERVAL_SECONDS):
        self._min_interval = min_interval
        self._queue: asyncio.Queue = asyncio.Queue()
        self._worker_task: Optional[asyncio.Task] = None
        self._last_call_time: float = 0.0
        self._running: bool = False
        self._lock = asyncio.Lock()

    async def _ensure_worker(self):
        """Garante que o worker está rodando. Inicia se necessário."""
        async with self._lock:
            if self._worker_task is None or self._worker_task.done():
                self._running = True
                self._worker_task = asyncio.create_task(self._worker())
                logger.debug("🔄 GeminiQueue worker iniciado")

    async def _worker(self):
        """
        Worker que processa requisições da fila uma por vez,
        respeitando o intervalo mínimo entre chamadas.
        """
        while self._running:
            try:
                # Aguarda próxima requisição com timeout para não travar indefinidamente
                try:
                    fn, future = await asyncio.wait_for(
                        self._queue.get(), timeout=30.0
                    )
                except asyncio.TimeoutError:
                    # Fila vazia por 30s — worker continua aguardando
                    continue

                # Respeita intervalo mínimo entre chamadas
                elapsed = time.monotonic() - self._last_call_time
                if elapsed < self._min_interval:
                    wait = self._min_interval - elapsed
                    logger.debug(f"⏳ GeminiQueue aguardando {wait:.1f}s antes da próxima chamada")
                    await asyncio.sleep(wait)

                # Executa a chamada
                try:
                    self._last_call_time = time.monotonic()
                    result = await fn()
                    if not future.done():
                        future.set_result(result)
                except Exception as e:
                    if not future.done():
                        future.set_exception(e)
                finally:
                    self._queue.task_done()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ GeminiQueue worker erro inesperado: {e}")
                await asyncio.sleep(1)

    async def submit(self, fn: Callable, timeout: float = QUEUE_TIMEOUT_SECONDS) -> Any:
        """
        Submete uma coroutine para execução serializada na fila.

        Args:
            fn: Callable assíncrono (coroutine function sem argumentos)
                Exemplo: lambda: gemini.analisar_contexto(prompt)
            timeout: Tempo máximo de espera na fila (segundos)

        Returns:
            Resultado da função fn

        Raises:
            asyncio.TimeoutError: se a fila não processar dentro do timeout
            Exception: qualquer exceção lançada pela fn
        """
        await self._ensure_worker()

        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()

        await self._queue.put((fn, future))

        logger.debug(f"📥 GeminiQueue: requisição enfileirada (fila: {self._queue.qsize()})")

        try:
            return await asyncio.wait_for(
                asyncio.shield(future), timeout=timeout
            )
        except asyncio.TimeoutError:
            logger.warning(
                f"⏱️ GeminiQueue timeout ({timeout}s) — requisição descartada da fila"
            )
            raise

    def qsize(self) -> int:
        """Retorna quantas requisições estão aguardando na fila."""
        return self._queue.qsize()

    async def stop(self):
        """Para o worker graciosamente."""
        self._running = False
        if self._worker_task and not self._worker_task.done():
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
        logger.debug("⏹️ GeminiQueue worker parado")


# ── Singleton global — compartilhado por todos os módulos ────────────────────
_gemini_queue: Optional[GeminiRequestQueue] = None


def get_gemini_queue() -> GeminiRequestQueue:
    """
    Retorna a instância singleton da fila global.
    Cria na primeira chamada.
    """
    global _gemini_queue
    if _gemini_queue is None:
        _gemini_queue = GeminiRequestQueue(min_interval=MIN_INTERVAL_SECONDS)
        logger.info(
            f"✅ GeminiQueue inicializada — intervalo mínimo: {MIN_INTERVAL_SECONDS}s "
            f"(~{60 / MIN_INTERVAL_SECONDS:.0f} req/min)"
        )
    return _gemini_queue
