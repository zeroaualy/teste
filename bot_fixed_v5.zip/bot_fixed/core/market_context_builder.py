"""
Market Context Builder — Bot Q3 Beta
Middleware isolado que recebe candles, calcula indicadores técnicos via
technical_indicators.py e retorna contexto estruturado pronto para
injeção no prompt da IA.

DESIGN:
- Totalmente isolado: não altera nenhum fluxo existente
- Retorna sempre um resultado seguro (nunca lança exceção para cima)
- Compatível com o rate limit: o cálculo é local (CPU), zero chamadas de API
- Expansível: novos indicadores são adicionados apenas em technical_indicators.py

USO:
    from core.market_context_builder import MarketContextBuilder
    builder = MarketContextBuilder()
    bloco_texto = builder.construir_contexto(candles, ativo="EURUSD")
    # Insira bloco_texto no prompt antes de chamar a IA
"""

import logging
from typing import List, Any, Optional, Dict

from core.technical_indicators import formatar_para_prompt, calcular_indicadores

logger = logging.getLogger(__name__)


class MarketContextBuilder:
    """
    Middleware que transforma candles brutos em contexto técnico estruturado
    para alimentar o prompt da IA com informações de qualidade.

    Thread-safe: apenas leitura de dados + cálculos locais (sem estado mutável).
    """

    def construir_contexto(
        self,
        candles: List[Any],
        ativo: str = "",
    ) -> str:
        """
        Ponto de entrada principal.

        Args:
            candles: Lista de candles (dict com open/high/low/close ou objeto)
            ativo: Nome do ativo para identificação no bloco de texto

        Returns:
            Bloco de texto formatado com indicadores técnicos.
            Retorna string vazia se candles insuficientes ou pandas indisponível.
            NUNCA lança exceção.
        """
        try:
            if not candles or len(candles) == 0:
                logger.debug(
                    f"[MarketContextBuilder] Candles vazios para {ativo or 'ativo'}"
                )
                return ""

            bloco = formatar_para_prompt(candles, ativo=ativo)

            if bloco:
                logger.debug(
                    f"[MarketContextBuilder] Contexto técnico gerado para "
                    f"{ativo or 'ativo'} ({len(candles)} candles)"
                )

            return bloco

        except Exception as e:
            logger.error(
                f"[MarketContextBuilder] Erro ao construir contexto para "
                f"{ativo or 'ativo'}: {e}"
            )
            return ""

    def construir_contexto_multi(
        self,
        dados: Dict[str, List[Any]],
    ) -> str:
        """
        Constrói contexto técnico para múltiplos ativos de uma vez.
        Útil para o FutureSignalGenerator que analisa vários ativos no mesmo prompt.

        Args:
            dados: Dict {nome_ativo: lista_candles}

        Returns:
            Bloco de texto com indicadores de todos os ativos disponíveis,
            separados por linha em branco. Retorna string vazia se nenhum
            ativo tiver dados suficientes.
        """
        try:
            blocos = []
            for ativo, candles in dados.items():
                if not candles:
                    continue
                bloco = self.construir_contexto(candles, ativo=ativo)
                if bloco:
                    blocos.append(bloco)

            return "\n\n".join(blocos) if blocos else ""

        except Exception as e:
            logger.error(
                f"[MarketContextBuilder] Erro ao construir contexto multi-ativo: {e}"
            )
            return ""

    def obter_indicadores_raw(
        self,
        candles: List[Any],
    ) -> Dict:
        """
        Retorna os indicadores como dict Python (não formatado como texto).
        Útil para quem precisar processar os valores numericamente.

        Args:
            candles: Lista de candles

        Returns:
            Dict com chaves rsi, macd, bollinger, ema_fast, ema_slow, disponivel, erro
        """
        try:
            return calcular_indicadores(candles)
        except Exception as e:
            logger.error(f"[MarketContextBuilder] Erro em obter_indicadores_raw: {e}")
            return {
                "rsi": None, "macd": None, "bollinger": None,
                "ema_fast": None, "ema_slow": None,
                "disponivel": False, "erro": str(e),
            }


# ── Instância singleton para uso direto (opcional) ───────────────────────────
# Permite usar: from core.market_context_builder import context_builder
context_builder = MarketContextBuilder()
